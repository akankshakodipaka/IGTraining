package week1Assessment;

public class LowBalanceException extends Exception{

	public LowBalanceException(String message) {
		// TODO Auto-generated constructor stub
		super(message);
	}

}
