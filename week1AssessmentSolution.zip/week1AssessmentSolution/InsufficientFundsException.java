package week1Assessment;

public class InsufficientFundsException extends Exception {

	public InsufficientFundsException(String message) {
		// TODO Auto-generated constructor stub
		super(message);
	}

}
