package week1Assessment;
import java.util.ArrayList;
import java.util.List;

public class AccountService {
    List<Account> accountList = new ArrayList<>();

    public boolean isValidAccount(int accNumber) throws AccountNotFoundException {
        for (Account account : accountList) {
            if (account.getAccNumber().equals(accNumber)) {
                return true;
            }
        }
        throw new AccountNotFoundException("Account not found with account number: " + accNumber);
    }

    public void depositAll(float amt) throws InvalidAmountException {
        if (amt < 0) {
            throw new InvalidAmountException("Amount cannot be negative");
        }
        for (Account account : accountList) {
            account.setBalance(account.getBalance() + amt);
        }
    }
//    public void deposit(float amt,Integer id) throws InvalidAmountException {
//        if (amt < 0) {
//            throw new InvalidAmountException("Amount cannot be negative");
//        }
//   
//        for (Account account : accountList) {
//        	if(account.getAccNumber()==id)
//        	{
//            account.setBalance(account.getBalance() + amt);
//            break;
//        	}
//        }
    //}
    public void deposit(float amt, Integer id) throws InvalidAmountException {
        if (amt < 0) {
            throw new InvalidAmountException("Amount cannot be negative");
        }

        for (Account account : accountList) {
            if (account.getAccNumber() == id) {
                account.setBalance(account.getBalance() + amt);
                break;
            }
        }
    }

    public void withdraw(int accNumber, float amt) throws AccountNotFoundException, InvalidAmountException, InsufficientFundsException {
        Account account = null;
        for (Account acc : accountList) {
            if (acc.getAccNumber().equals(accNumber)) {
                account = acc;
                break;
            }
        }

        if (account == null) {
            throw new AccountNotFoundException("Account not found with account number: " + accNumber);
        }

        if (amt < 500) {
            throw new InvalidAmountException("Minimum withdrawal amount is 500");
        }

        float newBalance = account.getBalance() - amt;

        if (account.getType() == Account.AccountType.SAVINGS && newBalance < 1000) {
            throw new InsufficientFundsException("Insufficient funds. Minimum balance for savings account is 1000");
        } else if (account.getType() == Account.AccountType.CURRENT && newBalance < 5000) {
            throw new InsufficientFundsException("Insufficient funds. Minimum balance for current account is 5000");
        }

        account.setBalance(newBalance);
    }

    public float getBalance(int accNumber) throws AccountNotFoundException {
        for (Account account : accountList) {
            if (account.getAccNumber().equals(accNumber)) {
                return account.getBalance();
            }
        }
        throw new AccountNotFoundException("Account not found with account number: " + accNumber);
    }
}

