package week1Assessment;

import week1Assessment.Account.AccountType;

public class AccountTest {
    public static void main(String[] args) {
        try {
            AccountService accountService = new AccountService();

            // Create accounts
            Account acc1 = new Account(101, "Akanksha", AccountType.SAVINGS, 2000f);
            Account acc2 = new Account(102, "Ajay", AccountType.CURRENT, 6000f);
            Account acc3 = new Account(507, "Poojitha", AccountType.SAVINGS, 8000f);
            Account acc4 = new Account(998, "Raju", AccountType.CURRENT, 9000f);
            Account acc5 = new Account(777, "Bhavya", AccountType.SAVINGS, 7000f);
            Account acc6 = new Account(302, "Farha", AccountType.CURRENT, 5000f);

            accountService.accountList.add(acc1);
            accountService.accountList.add(acc2);
            accountService.accountList.add(acc3);
            accountService.accountList.add(acc4);
            accountService.accountList.add(acc5);
            accountService.accountList.add(acc6);
            System.out.println("Balance of account 101: " + accountService.getBalance(101));
            System.out.println("Balance of account 102: " + accountService.getBalance(102));
            System.out.println("Balance of account 998: " + accountService.getBalance(998));
            System.out.println("Balance of account 777: " + accountService.getBalance(777));
            System.out.println("Balance of account 507: " + accountService.getBalance(507));
            System.out.println("Balance of account 302: " + accountService.getBalance(302));

            System.out.println(accountService.isValidAccount(101));
            System.out.println(accountService.isValidAccount(200));  
            accountService.deposit(1000f,777);
            accountService.depositAll(500f); 
            accountService.withdraw(777, 1500f); 
            System.out.println("Balance of account 101: " + accountService.getBalance(101));
            System.out.println("Balance of account 102: " + accountService.getBalance(102));
            System.out.println("Balance of account 998: " + accountService.getBalance(998));
            System.out.println("Balance of account 777: " + accountService.getBalance(777));
            System.out.println("Balance of account 507: " + accountService.getBalance(507));
            System.out.println("Balance of account 302: " + accountService.getBalance(302));

        } catch (AccountNotFoundException | InvalidAmountException | InsufficientFundsException | LowBalanceException e) {
            System.out.println(e.getMessage());
        }
    }
}
